﻿using static System.Console;

namespace MLTest;

internal class Program
{
    static int Main(string[] args)
    {
        // Ensure relative model path (SentimentModel.mlnet) resolves from app output directory.
        Directory.SetCurrentDirectory(AppContext.BaseDirectory);

        WriteLine("=== MLTest - Predict GradeClass from CSV (using existing model) ===");

        if (args.Length == 0)
        {
            WriteLine("Usage:");
            WriteLine("  dotnet run --project .\\MLTest\\MLTest.csproj -- <path-to-test-csv>");
            WriteLine();
            WriteLine("Example:");
            WriteLine("  dotnet run --project .\\MLTest\\MLTest.csproj -- C:\\data\\student_test.csv");
            return 1;
        }

        var csvPath = args[0];
        var exitCode = CsvBatchPredictor.Run(csvPath);

        WriteLine();
        WriteLine(exitCode == 0 ? "Done." : "Finished with errors.");
        return exitCode;
    }
}
